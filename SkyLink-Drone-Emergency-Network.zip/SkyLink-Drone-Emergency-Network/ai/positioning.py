from math import radians, cos, sin, asin, sqrt

def distance_km(a, b):
    lat1, lon1 = map(radians, a)
    lat2, lon2 = map(radians, b)
    dlat, dlon = lat2-lat1, lon2-lon1
    h = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return 6371 * 2 * asin(sqrt(h))

def optimal_position(nodes):
    """Simple centroid baseline; replace with clustering/optimization later."""
    if not nodes:
        raise ValueError("At least one SOS node is required.")
    return (
        sum(n[0] for n in nodes) / len(nodes),
        sum(n[1] for n in nodes) / len(nodes),
    )

if __name__ == "__main__":
    nodes = [(13.0827, 80.2707), (13.09, 80.28), (13.075, 80.26)]
    print("Recommended drone position:", optimal_position(nodes))
