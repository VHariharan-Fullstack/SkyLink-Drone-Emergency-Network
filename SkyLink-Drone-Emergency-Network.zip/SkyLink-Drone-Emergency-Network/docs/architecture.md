# Architecture

SkyLink uses ground SOS nodes, LoRa communication, an airborne receiver, a Raspberry Pi gateway, and a rescue dashboard.

`SOS Node -> LoRa -> Drone -> Gateway -> Dashboard -> Rescue Team`
