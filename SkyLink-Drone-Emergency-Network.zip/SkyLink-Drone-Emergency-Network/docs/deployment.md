# Deployment

1. Bench-test the ESP32 LoRa nodes.
2. Run the Raspberry Pi gateway and Flask dashboard.
3. Verify SOS packets end-to-end on the ground.
4. Only then integrate hardware with a suitable drone platform.
5. Follow local aviation, radio-spectrum, privacy, and emergency-service regulations.
