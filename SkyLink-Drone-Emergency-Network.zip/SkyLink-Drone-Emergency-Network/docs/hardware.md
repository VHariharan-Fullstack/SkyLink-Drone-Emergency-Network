# Hardware

Prototype hardware: quadcopter, ESP32 boards, Raspberry Pi, Neo-6M GPS, SX1278 LoRa modules, optional cellular backhaul, camera, and suitable power supplies.

Pin assignments and power requirements must be verified for the exact modules used before assembly.
