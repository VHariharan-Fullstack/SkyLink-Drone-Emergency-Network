# Communication

The prototype uses LoRa for low-bandwidth SOS packets. Cellular/Wi-Fi is treated as optional backhaul, not as a replacement cellular tower.
