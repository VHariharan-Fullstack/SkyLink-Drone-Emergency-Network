# SkyLink – Drone-Based Emergency Mobile Network Restorer

SkyLink is a drone-assisted emergency communication prototype for disaster areas where conventional communication infrastructure has failed.

## Prototype Features
- ESP32 + LoRa SOS transmitter
- Drone-side LoRa receiver
- Raspberry Pi gateway
- Flask rescue dashboard
- SQLite emergency database
- GPS/SOS message handling
- Simple AI-assisted positioning demo
- Emergency data simulator

## Architecture
SOS Node -> LoRa -> Drone Receiver -> Raspberry Pi Gateway -> Rescue Dashboard

## Quick Start
1. Install Python 3.
2. Run: `pip install -r requirements.txt`
3. Start the dashboard: `python dashboard/app.py`
4. Open `http://127.0.0.1:5000`
5. In another terminal run: `python simulation/emergency_simulator.py`

## Hardware
- Quadcopter
- ESP32
- Raspberry Pi
- Neo-6M GPS
- LoRa SX1278
- GSM/4G module (optional backhaul)
- Camera
- Battery

## Important Scope
This educational prototype creates an independent emergency messaging link using LoRa. It is not a licensed LTE/5G cellular base station.

## Author
Hariharan V  
B.Tech – Artificial Intelligence and Data Science
