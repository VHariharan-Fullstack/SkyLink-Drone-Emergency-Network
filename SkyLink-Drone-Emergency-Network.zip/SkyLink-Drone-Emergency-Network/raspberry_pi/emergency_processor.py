PRIORITIES = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

def normalize_emergency(data):
    required = ["device_id", "latitude", "longitude", "message"]
    missing = [key for key in required if key not in data]
    if missing:
        raise ValueError("Missing fields: " + ", ".join(missing))

    priority = str(data.get("priority", "MEDIUM")).upper()
    if priority not in PRIORITIES:
        priority = "MEDIUM"

    return {
        "device_id": str(data["device_id"]),
        "type": str(data.get("type", "GENERAL")).upper(),
        "latitude": float(data["latitude"]),
        "longitude": float(data["longitude"]),
        "message": str(data["message"]),
        "priority": priority,
    }
