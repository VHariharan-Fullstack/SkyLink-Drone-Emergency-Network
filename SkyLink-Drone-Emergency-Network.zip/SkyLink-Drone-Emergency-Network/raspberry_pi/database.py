import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parents[1] / "skylink.db"

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS emergencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT,
            type TEXT,
            latitude REAL,
            longitude REAL,
            message TEXT,
            priority TEXT,
            status TEXT DEFAULT 'NEW',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
