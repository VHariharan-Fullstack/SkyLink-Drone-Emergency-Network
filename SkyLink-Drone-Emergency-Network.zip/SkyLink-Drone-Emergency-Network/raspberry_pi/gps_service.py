def parse_demo_gps():
    """Replace this with serial/NMEA GPS input on Raspberry Pi."""
    return {"latitude": 13.0827, "longitude": 80.2707}
