import json
import sys
import requests
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))
from raspberry_pi.emergency_processor import normalize_emergency

DASHBOARD_API = "http://127.0.0.1:5000/api/emergencies"

def forward_packet(raw_packet):
    emergency = normalize_emergency(json.loads(raw_packet))
    response = requests.post(DASHBOARD_API, json=emergency, timeout=5)
    response.raise_for_status()
    return response.json()

if __name__ == "__main__":
    print("SkyLink gateway demo. Paste one JSON LoRa packet per line.")
    while True:
        try:
            packet = input("> ").strip()
            if packet:
                print(forward_packet(packet))
        except (KeyboardInterrupt, EOFError):
            break
        except Exception as exc:
            print("Gateway error:", exc)
