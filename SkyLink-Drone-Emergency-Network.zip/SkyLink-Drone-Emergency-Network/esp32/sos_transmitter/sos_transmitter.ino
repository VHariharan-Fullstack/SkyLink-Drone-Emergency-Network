#include <SPI.h>
#include <LoRa.h>

#define SS 5
#define RST 14
#define DIO0 2

void setup() {
  Serial.begin(115200);
  LoRa.setPins(SS, RST, DIO0);
  if (!LoRa.begin(433E6)) {
    Serial.println("LoRa initialization failed.");
    while (true) {}
  }
  Serial.println("SkyLink SOS transmitter ready.");
}

void loop() {
  String payload =
    "{\"device_id\":\"SOS-001\",\"type\":\"MEDICAL\","
    "\"latitude\":13.0827,\"longitude\":80.2707,"
    "\"message\":\"Medical assistance required\","
    "\"priority\":\"HIGH\"}";

  LoRa.beginPacket();
  LoRa.print(payload);
  LoRa.endPacket();

  Serial.println(payload);
  delay(10000);
}
