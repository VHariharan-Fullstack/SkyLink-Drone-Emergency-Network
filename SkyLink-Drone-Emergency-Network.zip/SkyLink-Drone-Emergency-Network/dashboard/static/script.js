async function loadEmergencies(){
  const status = document.getElementById("status");
  try {
    const res = await fetch("/api/emergencies");
    const items = await res.json();
    status.textContent = `${items.length} emergency request(s)`;
    document.getElementById("cards").innerHTML = items.map(e => `
      <section class="card">
        <h3 class="${e.priority}">${e.priority} — ${e.type}</h3>
        <p>${e.message}</p>
        <p class="meta">Device: ${e.device_id} | GPS: ${e.latitude}, ${e.longitude}</p>
        <p class="meta">Status: ${e.status} | Received: ${e.created_at}</p>
      </section>`).join("");
  } catch(err) {
    status.textContent = "Dashboard API unavailable.";
  }
}
loadEmergencies();
setInterval(loadEmergencies, 5000);
