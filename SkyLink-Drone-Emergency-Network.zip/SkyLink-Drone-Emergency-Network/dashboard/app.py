import sys
from pathlib import Path
from flask import Flask, jsonify, render_template, request

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from raspberry_pi.database import connect, init_db
from raspberry_pi.emergency_processor import normalize_emergency

app = Flask(__name__)
init_db()

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/emergencies")
def list_emergencies():
    with connect() as con:
        rows = con.execute(
            """SELECT * FROM emergencies
               ORDER BY CASE priority
                 WHEN 'CRITICAL' THEN 4 WHEN 'HIGH' THEN 3
                 WHEN 'MEDIUM' THEN 2 ELSE 1 END DESC, id DESC"""
        ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/emergencies")
def create_emergency():
    try:
        item = normalize_emergency(request.get_json(force=True))
    except (ValueError, TypeError) as exc:
        return jsonify({"error": str(exc)}), 400

    with connect() as con:
        cur = con.execute(
            """INSERT INTO emergencies
               (device_id, type, latitude, longitude, message, priority)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (item["device_id"], item["type"], item["latitude"],
             item["longitude"], item["message"], item["priority"])
        )
    return jsonify({"ok": True, "id": cur.lastrowid}), 201

if __name__ == "__main__":
    app.run(debug=True)
