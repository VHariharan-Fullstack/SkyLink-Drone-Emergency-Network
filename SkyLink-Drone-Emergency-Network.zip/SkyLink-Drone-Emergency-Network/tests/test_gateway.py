from raspberry_pi.emergency_processor import normalize_emergency

def test_priority():
    item = normalize_emergency({
        "device_id": "SOS-1",
        "latitude": 1,
        "longitude": 2,
        "message": "Help",
        "priority": "high"
    })
    assert item["priority"] == "HIGH"
