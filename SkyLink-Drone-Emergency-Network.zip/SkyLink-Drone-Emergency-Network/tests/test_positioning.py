from ai.positioning import optimal_position

def test_centroid():
    assert optimal_position([(0, 0), (2, 2)]) == (1.0, 1.0)
