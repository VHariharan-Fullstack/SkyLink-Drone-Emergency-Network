import random
import time
import requests

URL = "http://127.0.0.1:5000/api/emergencies"
messages = [
    ("MEDICAL", "Person injured. Medical assistance required.", "CRITICAL"),
    ("RESCUE", "Family trapped and requires evacuation.", "HIGH"),
    ("SUPPLY", "Drinking water required.", "MEDIUM"),
]

for i in range(1, 6):
    kind, message, priority = random.choice(messages)
    payload = {
        "device_id": f"SOS-{i:03}",
        "type": kind,
        "latitude": 13.0827 + random.uniform(-0.03, 0.03),
        "longitude": 80.2707 + random.uniform(-0.03, 0.03),
        "message": message,
        "priority": priority,
    }
    try:
        r = requests.post(URL, json=payload, timeout=5)
        print(r.status_code, r.json())
    except requests.RequestException as exc:
        print("Start dashboard/app.py first:", exc)
        break
    time.sleep(1)
